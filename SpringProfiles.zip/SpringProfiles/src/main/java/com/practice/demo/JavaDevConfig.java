package com.practice.demo;

import javax.annotation.PostConstruct;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("dev")
public class JavaDevConfig {

	@PostConstruct //Spring calls methods annotated with @PostConstruct only once, just after the initialization of bean properties.
	public void test()
	{
		System.out.println("Loaded on DEV environment");
	}
}
